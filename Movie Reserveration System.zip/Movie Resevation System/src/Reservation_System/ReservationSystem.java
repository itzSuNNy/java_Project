package Reservation_System;

import java.lang.reflect.InvocationTargetException;
import java.util.*;
//import from JSql library
import java.sql.*;
//import from JSch library(Java Secure Channel) 
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;

public class ReservationSystem {

    public Session session;						// SSH tunnel session
    Connection connection;                                              //create connection

    /**
     * Open SSH Tunnel to SSH server and forward the specified port on the local
     * machine to the MySQL port on the MySQL server on the SSH server
     *
     * @param sshUser SSH username
     * @param sshPassword SSH password
     * @param sshHost hostname or IP of SSH server
     * @param sshPort SSH port on SSH server
     * @param remoteHost hostname or IP of MySQL server on SSH server (from the
     * perspective of the SSH Server)
     * @param localPort port on the local machine to be forwarded
     * @param remotePort MySQL port on remoteHost
     */
    private void openSSHTunnel(String sshUser, String sshPassword, String sshHost, int sshPort, String remoteHost, int localPort, int remotePort) {
        try {
            final JSch jsch = new JSch();							// create a new Java Secure Channel
            session = jsch.getSession(sshUser, sshHost, sshPort);                               // get the tunnel
            session.setPassword(sshPassword);                                                    // set the password for the tunnel

            final Properties config = new Properties();                                         // create a properties object
            config.put("StrictHostKeyChecking", "no");                                          // set some properties
            session.setConfig(config);                                                          // set the properties object to the tunnel

            session.connect();                                                                  // open the tunnel
            System.out.println("\nSSH Connecting ***********************************************************************************************************************");
            System.out.println("Success: SSH tunnel open - you are connecting to " + sshHost + "on port " + sshPort + " with username " + sshUser);

            // set up port forwarding from a port on your local machine to a port on the MySQL server on the SSH server
            session.setPortForwardingL(localPort, remoteHost, remotePort);
            // output a list of the ports being forwarded

            System.out.println("Success: Port forwarded - You have forwared port " + localPort + " on the local machine to port " + remotePort + " on " + remoteHost + " on " + sshHost);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * Close SSH tunnel to a remote server
     */
    private void closeSshTunnel(int localPort) {
        try {
            // remove the port forwarding and output a status message
            System.out.println("\nSSH Connection Closing ******************************************************************************************************************");
            session.delPortForwardingL(localPort);
            System.out.println("Success: Port forwarding removed");
            // catch any exceptions
        } catch (JSchException e) {
            System.out.println("Error: port forwarding removal issue");
            e.printStackTrace();
        }
        // disconnect the SSH tunnel
        session.disconnect();
        System.out.println("Success: SSH tunnel closed\n");
    }

    /**
     * Open a connection with MySQL server. If there is an SSH Tunnel required
     * it will open this too.
     */
    public void openConnection(String mysqlHost, int localPort, String mysqlDatabaseName, String mysqlUsername, String mysqlPassword) {
        try {
            // create a new JDBC driver to facilitate the conversion of MySQL to java and vice versa
            Class.forName("com.mysql.cj.jdbc.Driver").getDeclaredConstructor().newInstance();

            // connect to the MySQL database through the SSH tunnel you have created using the variable above
            String jdbcConnectionString = "jdbc:mysql://" + mysqlHost + ":" + localPort + "/" + mysqlDatabaseName + "?user=" + mysqlUsername + "&password= " + mysqlPassword + "useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC";
            System.out.println("\nMySQL Connecting *********************************************************************************************************************");
//            System.out.println("JDBC connection string " + jdbcConnectionString);
            connection = DriverManager.getConnection(jdbcConnectionString, mysqlUsername, mysqlPassword);
//            System.out.println("Connection:" + connection.toString());
            System.out.println("Success: MySQL connection open");

        } // catch various exceptions and print error messages
        catch (SQLException e) {
            System.err.println("> SQLException: " + e.getMessage());
            e.printStackTrace();
        } catch (InstantiationException e) {
            System.err.println("> InstantiationException: " + e.getMessage());
            e.printStackTrace();
        } catch (IllegalAccessException e) {
            System.err.println("> IllegalAccessException: " + e.getMessage());
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            System.err.println("> ClassNotFoundException: " + e.getMessage());
            e.printStackTrace();
        } catch (IllegalArgumentException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (InvocationTargetException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (NoSuchMethodException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (SecurityException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }

    public void closeConnection() {
        System.out.println("\nMySQL Connection Closing ****************************************************************************************************************");
        try {
            connection.close(); // close database connection
            System.out.println("Success: MySQL connection closed.");
        } catch (SQLException e) {
            System.out.println("Error: Could not close MySQL connection");
            System.err.println(e);
            e.printStackTrace();
        }
    }

    //Customer registration method
    public void customerRegistration() {

//        New object for input
        Scanner sc = new Scanner(System.in);

//        taking customer detail
        System.out.println("Enter Your name :");
        String name = sc.nextLine();
        System.out.println("Address :");
        String address = sc.nextLine();
        System.out.println("Enter your phone No :");
        String p_no = sc.nextLine();
        System.out.println("------------------------------------------------");

//        print customer details 
        System.out.println("Name : " + name);
        System.out.println("Adress : " + address);
        System.out.println("Phone NO : " + p_no);
        System.out.println("Data inserted successfully");

//        insert customer details into database
        try {
            // create an SQL statement
            Statement st = connection.createStatement();
//            insertion sql query
            String insert = "INSERT INTO `customer`(`Full_Name`, `Phone_Number`, `Address`) VALUES ('" + name + "','" + p_no + "','" + address + "')";
            st.executeUpdate(insert);
        } catch (Exception e) {
            System.err.println(e);
        }
    }
//    Check Cutomer ID in reservation table

    private int customerCheck_in_reservation(int c_id) {
        int customer_check_in_reservation = 0; // Comparision variable 
        // get customer data from reservation table and compare  
        try {
            Statement check_c_id_in_reservation = connection.createStatement(); // create an SQL statement 
            ResultSet check_c_id_result = check_c_id_in_reservation.executeQuery("SELECT `c_ID` FROM `reservation` WHERE c_ID='" + c_id + "'"); // Query execute
            while (check_c_id_result.next()) {
                int temp_c_id = check_c_id_result.getInt("c_ID");
                if (temp_c_id == c_id) {
                    customer_check_in_reservation = temp_c_id;
                }
            }
        } catch (Exception e) {
            System.err.println(e);
        }
        return customer_check_in_reservation;
    }
// Check customer id in customer table

    private int customerCheck_in_customer(int c_id) {
        int customer_check_in_cutomer = 0;
        // get customer data from customertable and compare  
        try {
            Statement select_c_id_from_customer = connection.createStatement(); // create an SQL statement
            ResultSet c_id_result = select_c_id_from_customer.executeQuery("SELECT `id` FROM `customer` WHERE id='" + c_id + "'"); //Query execute
            while (c_id_result.next()) {
                int temp_c_id = c_id_result.getInt("id");
                customer_check_in_cutomer = temp_c_id;
            }
        } catch (Exception e) {
            System.err.println(e);
        }
        return customer_check_in_cutomer;
    }
// Check Reservation if reserved by customer

    public void checkReservation(int c_id) {
        if (customerCheck_in_reservation(c_id) == c_id) {
            // Display movie which is reserved by customer
            try {
                Statement reservation_movie_selection = connection.createStatement();                  // create an SQL statement
                Statement movie_selection = connection.createStatement();                               // create an SQL statement
                ResultSet movie_reservation = reservation_movie_selection.executeQuery("SELECT `m_ID`FROM `reservation` WHERE c_ID='" + c_id + "'");    // retrieve an SQL results set
                while (movie_reservation.next()) {
                    int m_id = movie_reservation.getInt("m_ID");       // hold value from database to varible

                    try {
                        ResultSet movie_detail = movie_selection.executeQuery("SELECT * FROM `movie` WHERE movie_ID='" + m_id + "'");   // retrieve an SQL results set
                        while (movie_detail.next()) {

                            // hold value from database to varible
                            int temp_movie_ID = movie_detail.getInt("movie_ID");
                            String movieName = movie_detail.getString("movie_Name");
                            float rating = movie_detail.getFloat("rating");
                            int release_year = movie_detail.getInt("release_year");
                            String genre = movie_detail.getString("genre");

                            //  print hold data
                            System.out.println("Movie ID    :" + temp_movie_ID);
                            System.out.println("Movie Name  : " + movieName);
                            System.out.println("Rating      :" + rating);
                            System.out.println("Release Year:" + release_year);
                            System.out.println("Genere      :" + genre);
                            System.out.println("---------------------------------------------------------------------------------------------");
                        }
                    } catch (Exception e) {
                        System.out.println(e);
                    }
                }
            } catch (Exception e) {
                System.out.println(e);
            }
        } else {
            System.out.println("Customer does not reserved any movie");
        }
    }
// View reservation

    public void viewReservation() {
        //        New object for input
        Scanner sc = new Scanner(System.in);

//        show all name and id of customer 
        try {
            Statement select_all_detail_from_customer = connection.createStatement(); 							// create an SQL statement
            ResultSet customer_detail_result = select_all_detail_from_customer.executeQuery("SELECT * from customer");                          // retrieve an SQL results set

            // show detail of customer (ID , Name) from Customer Table 
            while (customer_detail_result.next()) {
                // hold value from database to varible
                int id = customer_detail_result.getInt("id");
                String Name = customer_detail_result.getString("Full_Name");
                //print detail of cutomer
                System.out.println("ID      customerName");
                System.out.println(id + "       " + Name);
                System.out.println("------------------------------------------------------");
            }

            // Ask customer ID
            System.out.println("Enter Customer ID : ");
            int runtimer_c_id = sc.nextInt();
            System.out.println("------------------------------------------------------");
            // Compare runtime customer id from customer table
            if (customerCheck_in_customer(runtimer_c_id) != runtimer_c_id) {
                System.out.println("Customer not present in database");
            } else {
                checkReservation(runtimer_c_id);
            }
        } catch (Exception e) {
            System.err.println(e);
        }
    }
// either customer not exist in resrvation table or customer is present but dosn't reserved given moive ID

    private void insertReservation(int c_id, int m_id) {
        Scanner sc = new Scanner(System.in); // creat input object
        System.out.print("Total seat : ");
        int seat = sc.nextInt();
        System.out.println("Amount : ");
        int amount = sc.nextInt();
        // insertion operation
        try {
            Statement insert_movie_into_reservation = connection.createStatement();
            System.out.println(c_id + " " + m_id + " " + seat + " " + amount);
            String new_reservation = "INSERT INTO `reservation`(`c_ID`, `m_ID`, `total_seat`,`amount`) VALUES ('" + c_id + "','" + m_id + "','" + seat + "','" + amount + "')";
            insert_movie_into_reservation.executeUpdate(new_reservation);
            System.out.println("Movie successfully reserved");
        } catch (Exception e) {
            System.err.println(e);
        }
    }
// main resrvation function

    public void makeReservation() {
        //        New object for input
        Scanner sc = new Scanner(System.in);

        int compare_m_id_in_reservation = 0;
        int compare_m_id_in_movie = 0;

        //        show all name and id of customer 
        try {

            Statement customer_statement = connection.createStatement(); 							// create an SQL statement
            ResultSet customer_result = customer_statement.executeQuery("SELECT * from Customer");                                 // retrieve an SQL results set
            // Print customer detail
            while (customer_result.next()) {
                int customerID = customer_result.getInt("id");
                String Name = customer_result.getString("Full_Name");

                System.out.println("ID      customerName");
                System.out.println(customerID + "       " + Name);
                System.out.println("----------------------------------------------");
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        System.out.println("Enter Customer ID : ");
        int runtime_c_id = sc.nextInt();

//        show all detail of movie in movie table 
        try {
            Statement show_movie_detail = connection.createStatement();
            ResultSet movie_detail_result = show_movie_detail.executeQuery("SELECT * from movie");
            while (movie_detail_result.next()) {
                int movieID = movie_detail_result.getInt("movie_ID");
                String movieName = movie_detail_result.getString("movie_Name");
                float rating = movie_detail_result.getFloat("rating");
                int release_year = movie_detail_result.getInt("release_year");
                String genre = movie_detail_result.getString("genre");

                System.out.println("Movie ID    :" + movieID);
                System.out.println("Movie Name  : " + movieName);
                System.out.println("Rating      :" + rating);
                System.out.println("Release Year:" + release_year);
                System.out.println("Genere      :" + genre);
                System.out.println("---------------------------------------------------------------------------------------------");
            }
        } catch (Exception e) {
            System.err.println(e);
        }

        if (customerCheck_in_customer(runtime_c_id) != runtime_c_id) {
            System.out.println("customer not present in database");
        } else {

            System.out.println("Enter Movie ID :");
            int runtime_m_id = sc.nextInt();
            // check movie wheather it available in movie table
            try {
                Statement check_m_id_from_movie = connection.createStatement();
                ResultSet check_movie_result = check_m_id_from_movie.executeQuery("SELECT `movie_ID` FROM `movie` ");
                while (check_movie_result.next()) {
                    int temp_movie_id = check_movie_result.getInt("movie_ID");
                    if (temp_movie_id == runtime_m_id) {
                        compare_m_id_in_movie = temp_movie_id;
                    }
                }
            } catch (Exception e) {
                System.err.println(e);
            }
//            Compare runtime movie ID from movie table
            if (compare_m_id_in_movie == runtime_m_id) {
                if ((customerCheck_in_reservation(runtime_c_id)) != runtime_c_id) {
                    System.out.println("Customer does not reserved any movie");
                    System.out.println("Do you want to reserved this movie press y or Y");
                    char res_choic = sc.next().charAt(0);
                    if (res_choic == 'y' || res_choic == 'Y') {

                        insertReservation(runtime_c_id, runtime_m_id);
                    }
                } else {
                    try {
                        Statement select_m_id_from_reservation = connection.createStatement(); // create SQL statement
                        ResultSet movie_resvation_result = select_m_id_from_reservation.executeQuery("SELECT `m_ID` FROM `reservation` WHERE c_ID='" + runtime_c_id + "' "); // execute query
                        // Hold movie ID from reservation table to local variable
                        while (movie_resvation_result.next()) {
                            int temp_m_id = movie_resvation_result.getInt("m_ID");
                            if (temp_m_id == runtime_m_id) {
                                compare_m_id_in_reservation = temp_m_id;
                            }
                        }
                        // compare local variable to the runtime movie ID
                        if (compare_m_id_in_reservation == runtime_m_id) {
                            System.out.println("You already reserved this movie");
                        } else if (compare_m_id_in_reservation != runtime_m_id) {
                            System.out.println("This movie is not reserved ");
                            System.out.println("Do you want to reserved this movie press y or Y");
                            char res_choic = sc.next().charAt(0);
                            if (res_choic == 'y' || res_choic == 'Y') {
                                insertReservation(runtime_c_id, runtime_m_id);
                            }
                        }
                    } catch (Exception e) {
                        System.err.println(e);
                    }
                }
            } else {
                System.out.println("Movie from this ID: " + runtime_m_id + " not present in database");
            }
        }
    }

    public void showStatstics() {
        Scanner sc = new Scanner(System.in); // Creating input object
        int choice;
        System.out.println("1. Top 3 popular movie by rating ");
        System.out.println("2. Movie which rating less than 5.0 ");
        System.out.println("3. Show 5 new latest movie ");
        System.out.println("4. Show 5 most old movies  ");
        System.out.println("5. show all movie from the following genre ");

        choice = sc.nextInt();

        switch (choice) {
            case 1: { // Show top 3 movie by rating 
                try {
                    Statement top_movie = connection.createStatement(); // Create SQL statement
                    ResultSet top_movie_result = top_movie.executeQuery("SELECT * FROM `movie` ORDER BY `rating` DESC LIMIT 0,3");
                    while (top_movie_result.next()) {
                        float rating = top_movie_result.getFloat("rating");
                        String movie = top_movie_result.getString("movie_name");
                        System.out.println("Movie : " + movie + "\nRating : " + rating);
                        System.out.println("-------------------------------------------------");
                    }
                } catch (Exception e) {
                    System.err.println(e);
                }
            }
            break;
            case 2: { // Show movie by rating less then 5
                try {
                    Statement rating_movie = connection.createStatement(); // Create SQL statement
                    ResultSet rating_movie_result = rating_movie.executeQuery("SELECT * FROM `movie` WHERE rating < 5");
                    while (rating_movie_result.next()) {
                        float rating = rating_movie_result.getFloat("rating");
                        String movie = rating_movie_result.getString("movie_name");
                        System.out.println("Movie : " + movie + "\nRating : " + rating);
                        System.out.println("-------------------------------------------------");
                    }
                } catch (Exception e) {
                    System.err.println(e);
                }

            }

            break;
            case 3: { // Show 5 latest movie
                try {
                    Statement new_movie = connection.createStatement(); // Create SQL statement
                    ResultSet new_movie_result = new_movie.executeQuery("SELECT * FROM `movie` ORDER BY release_Year DESC LIMIT 0,5");
                    while (new_movie_result.next()) {
                        int year = new_movie_result.getInt("release_Year");
                        String movie = new_movie_result.getString("movie_name");
                        System.out.println("Movie : " + movie + "\nRelease Year: " + year);
                        System.out.println("-------------------------------------------------");
                    }
                } catch (Exception e) {
                    System.err.println(e);
                }

            }

            break;
            case 4: { // Show 5 old movie 
                try {
                    Statement old_movie = connection.createStatement(); // Create SQL statement
                    ResultSet old_movie_result = old_movie.executeQuery("SELECT * FROM `movie` ORDER BY release_Year ASC LIMIT 0,5");
                    while (old_movie_result.next()) {
                        int year = old_movie_result.getInt("release_Year");
                        String movie = old_movie_result.getString("movie_name");
                        System.out.println("Movie : " + movie + "\nRelease Year : " + year);
                        System.out.println("-------------------------------------------------");
                    }
                } catch (Exception e) {
                    System.err.println(e);
                }

            }

            break;

            case 5: { // genere list
                System.out.println("1. Adventure ");
                System.out.println("2. Action ");
                System.out.println("3. Sci-Fi ");
                System.out.println("4. Horror ");
                System.out.println("5. Comedy ");

                choice = sc.nextInt(); // get genere from user

                switch (choice) {
                    case 1: { // show all adventure movies
                        try {
                            Statement adv = connection.createStatement(); // Create SQL statement
                            ResultSet adv_result = adv.executeQuery("SELECT * FROM `movie` WHERE genre='Adventure'");
                            while (adv_result.next()) {
                                String genere = adv_result.getString("genre");
                                String movie = adv_result.getString("movie_name");
                                System.out.println("Movie : " + movie + "\nGenere : " + genere);
                                System.out.println("-------------------------------------------------");
                            }
                        } catch (Exception e) {
                            System.out.println(e);
                        }
                    }
                    break;
                    case 2: {  // show all action movies
                        try {
                            Statement act = connection.createStatement(); // Create SQL statement
                            ResultSet act_result = act.executeQuery("SELECT * FROM `movie` WHERE genre='Action'");
                            while (act_result.next()) {
                                String genere = act_result.getString("genre");
                                String movie = act_result.getString("movie_name");
                                System.out.println("Movie : " + movie + "\nGenere : " + genere);
                                System.out.println("-------------------------------------------------");
                            }

                        } catch (Exception e) {
                            System.out.println(e);
                        }
                    }
                    break;
                    case 3: {  // show all Sci-fi movies
                        try {
                            Statement sfi = connection.createStatement(); // Create SQL statement
                            ResultSet sfi_result = sfi.executeQuery("SELECT * FROM `movie` WHERE genre='Sci-Fi'");
                            while (sfi_result.next()) {
                                String genere = sfi_result.getString("genre");
                                String movie = sfi_result.getString("movie_name");
                                System.out.println("Movie : " + movie + "\nGenere : " + genere);
                                System.out.println("-------------------------------------------------");
                            }

                        } catch (Exception e) {
                            System.out.println(e);
                        }
                    }
                    break;
                    case 4: { // show all Horrro movies
                        try {
                            Statement hor = connection.createStatement(); // Create SQL statement
                            ResultSet hor_result = hor.executeQuery("SELECT * FROM `movie` WHERE genre='Horror'");
                            while (hor_result.next()) {
                                String genere = hor_result.getString("genre");
                                String movie = hor_result.getString("movie_name");
                                System.out.println("Movie : " + movie + "\nGenere : " + genere);
                                System.out.println("-------------------------------------------------");
                            }

                        } catch (Exception e) {
                            System.out.println(e);
                        }
                    }
                    break;
                    case 5: { // show all Comedy movies
                        try {
                            Statement com = connection.createStatement(); // Create SQL statement
                            ResultSet com_result = com.executeQuery("SELECT * FROM `movie` WHERE genre='Comedy'");
                            while (com_result.next()) {
                                String genere = com_result.getString("genre");
                                String movie = com_result.getString("movie_name");
                                System.out.println("Movie : " + movie + "\nGenere : " + genere);
                                System.out.println("-------------------------------------------------");
                            }

                        } catch (Exception e) {
                            System.out.println(e);
                        }
                    }
                    break;
                    default:
                        System.out.println("Enter number b/w 1 to 5");
                        break;
                }
                break;
            }
            default:
                break;
        }
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Starting");
        String mysqlUsername = "root";
        String mysqlPassword = "";
        String mysqlDatabaseName = "moviereservation";
//        String sshUsername = "YOUR USERNAME";
//        String sshPassword = "YOUR PASSWORD";
//        String sshRemoteHost = "knuth.gcd.ie";
//        int shhRemotePort = 22;
        String mysqlHost = "localhost";
        int remoteMySQLPort = 3306;
        int localPort = 3306;
//      Creat reservation Object
        ReservationSystem obj = new ReservationSystem();
        // Create connection between MySql database and program
        obj.openConnection(mysqlHost, localPort, mysqlDatabaseName, mysqlUsername, mysqlPassword);
        char c;
        do {
            System.out.println(" 1. Register New Customer \n 2. View Reservation \n 3. Make Reservation \n 4. Show Statistics \n 5. Exit");
            int choice = sc.nextInt();

            switch (choice) {
                case 1:
                    obj.customerRegistration();
                    break;
                case 2:
                    obj.viewReservation();

                    break;
                case 3:
                    obj.makeReservation();
                    break;
                case 4:
                    obj.showStatstics();
                    break;
                case 5:
                    System.out.println("Exited");
                    break;
                default:
                    System.out.println("wrong input \n--------------------------------\n Please Enter number b/w 1 to 4 ");
                    break;
            }
            System.out.println("Do you want to return to the main menu press Y or y");
            c = sc.next().charAt(0);

        } while (c == 'y' || c == 'Y');

////        obj.openSSHTunnel(sshUsername, sshPassword, sshRemoteHost, shhRemotePort, mysqlHost, localPort, remoteMySQLPort);
////        obj.testConnection();
        obj.closeConnection();

//       obj.closeSshTunnel(localPort);
    }
}
