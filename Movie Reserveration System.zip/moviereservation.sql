-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 27, 2021 at 07:43 PM
-- Server version: 10.4.6-MariaDB
-- PHP Version: 7.1.32

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `moviereservation`
--

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `id` int(11) NOT NULL,
  `Full_Name` varchar(250) NOT NULL,
  `Phone_Number` varchar(20) DEFAULT NULL,
  `Address` varchar(250) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`id`, `Full_Name`, `Phone_Number`, `Address`) VALUES
(31, 'Hamza', '910000000', 'h-256'),
(32, 'ali', '080000000', 'h-4985'),
(33, 'arslan', '1321532321', 'h-573'),
(34, 'Mujahid', '805113131', '817-h');

-- --------------------------------------------------------

--
-- Table structure for table `movie`
--

CREATE TABLE `movie` (
  `movie_ID` int(11) NOT NULL,
  `movie_name` varchar(250) NOT NULL,
  `rating` float NOT NULL,
  `release_Year` int(5) NOT NULL,
  `genre` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `movie`
--

INSERT INTO `movie` (`movie_ID`, `movie_name`, `rating`, `release_Year`, `genre`) VALUES
(1, 'The Avenger 1', 6.5, 2016, 'Action'),
(2, 'Avenger : Age of ultron', 8.1, 2017, 'Action'),
(3, 'Ring ', 4.3, 2012, 'Horror'),
(4, 'The dictator', 7.4, 2017, 'Comedy'),
(5, 'Ring two', 6.1, 2017, 'Horror'),
(6, 'Aliens VS Predators', 5.5, 2006, 'Sci-Fi'),
(9, 'Jurassic Park', 3.5, 2012, 'Adventure'),
(11, 'Ring (2017)', 4.3, 2017, 'Horror'),
(12, 'Jhon wick', 7.5, 2015, 'Action');

-- --------------------------------------------------------

--
-- Table structure for table `reservation`
--

CREATE TABLE `reservation` (
  `reservation_ID` int(11) NOT NULL,
  `c_ID` int(11) NOT NULL,
  `m_ID` int(11) NOT NULL,
  `total_seat` int(11) NOT NULL,
  `amount` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `reservation`
--

INSERT INTO `reservation` (`reservation_ID`, `c_ID`, `m_ID`, `total_seat`, `amount`) VALUES
(26, 31, 12, 2, '2000'),
(27, 31, 9, 5, '10000'),
(28, 34, 6, 1, '2000');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `movie`
--
ALTER TABLE `movie`
  ADD PRIMARY KEY (`movie_ID`);

--
-- Indexes for table `reservation`
--
ALTER TABLE `reservation`
  ADD PRIMARY KEY (`reservation_ID`),
  ADD KEY `c_ID` (`c_ID`),
  ADD KEY `m_ID` (`m_ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `customer`
--
ALTER TABLE `customer`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;

--
-- AUTO_INCREMENT for table `movie`
--
ALTER TABLE `movie`
  MODIFY `movie_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `reservation`
--
ALTER TABLE `reservation`
  MODIFY `reservation_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `reservation`
--
ALTER TABLE `reservation`
  ADD CONSTRAINT `reservation_ibfk_1` FOREIGN KEY (`c_ID`) REFERENCES `customer` (`id`),
  ADD CONSTRAINT `reservation_ibfk_2` FOREIGN KEY (`m_ID`) REFERENCES `movie` (`movie_ID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
